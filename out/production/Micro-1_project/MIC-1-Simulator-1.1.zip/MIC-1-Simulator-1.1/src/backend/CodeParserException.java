package backend;

public class CodeParserException extends Exception{
    public CodeParserException(String message) {
        super(message);
    }
}
